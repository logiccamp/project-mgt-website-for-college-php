<?php


$host = "localhost";
$user = "root";
$password = "Alonso652@..";
$db = "supervise";
