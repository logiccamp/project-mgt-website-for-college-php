<?php
class FileUpload
{
    public function uploadProfileImage()
    {
    }
}
