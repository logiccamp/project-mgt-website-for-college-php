<div class="card p-2 my-4">
    <div class="px-3 py-2 pb-0">
        <h6 class="text-black-50 text-uppercase fw-bold">Lorem Ipsum Alabi</h6>
        <small>P/ND/18/2039</small>
        <div class="mt-3">
            <a href="" class="btn"> <span class="fa fa-comment-o text-dark"></span> &nbsp; Private Message</a>
        </div>
    </div>
    <div class="row m-0 flex_rotate">
        <div class="col-md-8 py-3">
            <table class="table">
                <tbody>
                    <tr>
                        <td>Name</td>
                        <td>Fullname</td>
                    </tr>
                    <tr>
                        <td>Matric No</td>
                        <td>Fullname</td>
                    </tr>
                    <tr>
                        <td>Level</td>
                        <td>Fullname</td>
                    </tr>

                    <tr>
                        <td>Program</td>
                        <td>Fullname</td>
                    </tr>

                    <tr>
                        <td>School</td>
                        <td>Fullname</td>
                    </tr>

                    <tr>
                        <td>Department</td>
                        <td>Fullname</td>
                    </tr>

                    <tr>
                        <td>Gender</td>
                        <td>Fullname</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-4 py-3 text-center">
            <img src="https://mdbcdn.b-cdn.net/img/new/avatars/8.webp" class="rounded-circle" alt="Avatar" width="200px" height="200px" /> <span class="mx-1"></span>
        </div>
    </div>

</div>