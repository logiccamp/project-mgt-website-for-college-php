$("#toggleAvatar").click(function(){
    $(".avartarDrop").toggle(100)
})

